GY-85 Arduino libraries source bundle

ADXL345
Source: https://github.com/sparkfun/SparkFun_ADXL345_Arduino_Library
Author: SparkFun Electronics

ITG3200
Source: https://github.com/sparkfun/IMU_Digital_Combo_Board
Author: SparkFun Electronics / Ryan Owens
IMPORTANT: the official SparkFun ITG3200 code is legacy AVR-oriented source.
It includes avr/io.h / twi / main dependencies and is NOT a modern ESP32-ready library.
It is packaged unchanged rather than substituted with another author's library.

HMC5883L
Source: https://github.com/jarzebski/Arduino-HMC5883L
Author: Korneliusz Jarzebski
Upstream GPL-3.0 license is included.

The sensor implementation files in this bundle are copied from the listed
upstream repositories.
